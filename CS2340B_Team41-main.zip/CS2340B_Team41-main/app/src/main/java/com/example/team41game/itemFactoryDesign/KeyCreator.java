package com.example.team41game.itemFactoryDesign;

public class KeyCreator extends ItemCreator {
    public Item createItem() {
        return new Key();
    }
}

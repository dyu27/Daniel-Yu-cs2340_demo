package com.example.team41game.itemFactoryDesign;

public class DaggerCreator extends ItemCreator {
    public Item createItem() {
        return new Dagger();
    }
}

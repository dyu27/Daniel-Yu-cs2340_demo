package com.example.team41game.itemFactoryDesign;

import com.example.team41game.viewModels.GameScreenViewModel;

public class FreezeDecorator extends PowerUpDecorator {
    public FreezeDecorator(PowerUpLauncher powerUpLauncher) {
        super(powerUpLauncher);
    }

    @Override
    public int applyPowerUp(GameScreenViewModel gameScreenViewModel) {
        gameScreenViewModel.getRoom().freeze();
        int powerUpTime = 7;
        return powerUpTime;
    }

    @Override
    public void terminatePowerUp(GameScreenViewModel gameScreenViewModel) {
        gameScreenViewModel.getRoom().unfreeze();
    }
}

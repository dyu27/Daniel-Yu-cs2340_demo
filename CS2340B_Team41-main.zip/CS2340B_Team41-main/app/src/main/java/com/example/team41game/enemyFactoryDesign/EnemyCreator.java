package com.example.team41game.enemyFactoryDesign;


public abstract class EnemyCreator {
    public abstract Enemy createEnemy(int x, int y);
}

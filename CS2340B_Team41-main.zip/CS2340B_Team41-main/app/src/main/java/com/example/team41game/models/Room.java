package com.example.team41game.models;

public class Room {
    private int[][] floorLayout;
    private boolean frozen;
    private boolean slow;
    private boolean paused;

    public Room(int[][] floorLayout) {
        this.floorLayout = floorLayout;
        this.frozen = false;
        this.slow = false;
        this.paused = false;
    }

    //use this to access floor plan in view model bounds checks
    public int[][] getFloorLayout() {
        return this.floorLayout;
    }

    public boolean isFrozen() {
        return this.frozen;
    }

    public void freeze() {
        this.frozen = true;
    }

    public void unfreeze() {
        this.frozen = false;
    }

    public boolean isSlow() {
        return this.slow;
    }

    public void slow() {
        this.slow = true;
    }

    public void quicken() {
        this.slow = false;
    }

    public boolean isPaused() {
        return this.paused;
    }

    public void setPaused(boolean paused) {
        this.paused = paused;
    }
}

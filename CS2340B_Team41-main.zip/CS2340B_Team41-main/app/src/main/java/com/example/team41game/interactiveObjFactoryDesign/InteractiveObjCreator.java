package com.example.team41game.interactiveObjFactoryDesign;


public abstract class InteractiveObjCreator {
    public abstract InteractiveObj createInteractiveObj(int x, int y, String type);
}

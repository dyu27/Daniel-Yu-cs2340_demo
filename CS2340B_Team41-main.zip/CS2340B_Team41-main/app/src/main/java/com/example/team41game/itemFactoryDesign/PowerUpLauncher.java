package com.example.team41game.itemFactoryDesign;

import com.example.team41game.viewModels.GameScreenViewModel;

public interface PowerUpLauncher {
    int applyPowerUp(GameScreenViewModel viewModel);

    void terminatePowerUp(GameScreenViewModel viewModel);
}

package com.example.team41game;

public interface MovePattern {
    // allows enemy to also implement move pattern
    void move(Position position);
}

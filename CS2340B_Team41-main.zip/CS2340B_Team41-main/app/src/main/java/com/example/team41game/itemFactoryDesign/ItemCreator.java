package com.example.team41game.itemFactoryDesign;

public abstract class ItemCreator {
    public abstract Item createItem();
}

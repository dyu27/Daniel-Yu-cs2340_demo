package com.example.team41game.itemFactoryDesign;

import com.example.team41game.viewModels.GameScreenViewModel;

public class HealthDecorator extends PowerUpDecorator {
    public HealthDecorator(PowerUpLauncher powerUpLauncher) {
        super(powerUpLauncher);
    }

    @Override
    public int applyPowerUp(GameScreenViewModel gameScreenViewModel) {
        gameScreenViewModel.restorePlayerHealth();
        int powerUpTime = 0;
        return powerUpTime;
    }
}

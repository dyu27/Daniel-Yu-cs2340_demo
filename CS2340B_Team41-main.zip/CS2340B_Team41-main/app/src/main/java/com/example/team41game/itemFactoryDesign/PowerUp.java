package com.example.team41game.itemFactoryDesign;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;

import com.example.team41game.interactiveObjFactoryDesign.InteractiveObj;
import com.example.team41game.viewModels.GameScreenViewModel;

public class PowerUp implements Item, PowerUpLauncher {
    private Resources res;
    private InteractiveObj container;
    private Boolean justDiscovered;
    private int sprite;
    private Bitmap bitmap;

    public PowerUp() {
        this.justDiscovered = false;
    }

    public void setContainer(InteractiveObj container) {
        this.container = container;
    }

    public InteractiveObj getContainer() {
        return container;
    }

    public void setBitmap(Resources res) {
        this.res = res;
        this.bitmap = BitmapFactory.decodeResource(this.res, this.sprite);
    }

    public void render(Canvas canvas, int tileWidth, int tileHeight) {
        canvas.drawBitmap(bitmap, getContainer().getPosition().getX() * tileWidth,
                getContainer().getPosition().getY() * tileHeight, null);
    }

    public void discover() {
        this.justDiscovered = true;
    }

    public boolean justDiscovered() {
        return this.justDiscovered;
    }

    public void acquire() {
        this.justDiscovered = false;
    }

    public void setSprite(int sprite) {
        this.sprite = sprite;
    }

    public int applyPowerUp(GameScreenViewModel gameScreenViewModel) {
        //undecorated power up does nothing
        return 0;
    }

    public void terminatePowerUp(GameScreenViewModel gameScreenViewModel) {
        return;
    }

    public int getSprite() {
        return sprite;
    }
}

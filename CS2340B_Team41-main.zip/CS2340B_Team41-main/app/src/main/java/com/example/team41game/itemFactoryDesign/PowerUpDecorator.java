package com.example.team41game.itemFactoryDesign;

import com.example.team41game.viewModels.GameScreenViewModel;

public class PowerUpDecorator implements PowerUpLauncher {
    protected PowerUpLauncher powerUpLauncher;

    public PowerUpDecorator(PowerUpLauncher powerUpLauncher) {
        this.powerUpLauncher = powerUpLauncher;
    }

    public int applyPowerUp(GameScreenViewModel gameScreenViewModel) {
        return powerUpLauncher.applyPowerUp(gameScreenViewModel);
    }

    public void terminatePowerUp(GameScreenViewModel gameScreenViewModel) {
        powerUpLauncher.terminatePowerUp(gameScreenViewModel);
    }
}

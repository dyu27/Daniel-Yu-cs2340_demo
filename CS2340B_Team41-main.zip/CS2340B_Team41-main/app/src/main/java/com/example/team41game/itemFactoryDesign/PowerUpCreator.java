package com.example.team41game.itemFactoryDesign;

public class PowerUpCreator extends ItemCreator {
    public Item createItem() {
        return new PowerUp();
    }
}

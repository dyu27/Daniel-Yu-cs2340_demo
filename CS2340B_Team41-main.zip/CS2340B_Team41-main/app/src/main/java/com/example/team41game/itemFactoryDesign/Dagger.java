package com.example.team41game.itemFactoryDesign;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;

import com.example.team41game.interactiveObjFactoryDesign.InteractiveObj;

public class Dagger implements Item {
    private Resources res;
    private InteractiveObj container;
    private Boolean justDiscovered;
    private int sprite;
    private Bitmap bitmap;
    private boolean visible;

    public Dagger() {
        this.justDiscovered = false;
        this.visible = false;
    }

    public void setContainer(InteractiveObj container) {
        this.container = container;
    }

    public InteractiveObj getContainer() {
        return container;
    }

    public void setBitmap(Resources res) {
        this.res = res;
        this.bitmap = BitmapFactory.decodeResource(this.res, this.sprite);
    }

    public void render(Canvas canvas, int tileWidth, int tileHeight) {
        canvas.drawBitmap(bitmap, getContainer().getPosition().getX() * tileWidth,
                getContainer().getPosition().getY() * tileHeight, null);
    }

    public void discover() {
        this.justDiscovered = true;
    }

    public boolean justDiscovered() {
        return this.justDiscovered;
    }

    public void acquire() {
        this.justDiscovered = false;
    }

    public void setSprite(int sprite) {
        this.sprite = sprite;
    }

    public void drawOnPlayer(Canvas canvas, int playerX, int playerY,
                             int tileWidth, int tileHeight) {
        int xOffset = 22;
        int yOffset = 12;
        canvas.drawBitmap(bitmap, playerX * tileWidth + xOffset,
                playerY * tileHeight + yOffset, null);
    }

    public boolean isVisible() {
        return this.visible;
    }

    public void setVisibility(boolean isVisible) {
        this.visible = isVisible;
    }
}

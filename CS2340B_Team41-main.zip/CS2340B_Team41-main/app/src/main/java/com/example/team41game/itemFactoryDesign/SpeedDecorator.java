package com.example.team41game.itemFactoryDesign;

import com.example.team41game.viewModels.GameScreenViewModel;

public class SpeedDecorator extends PowerUpDecorator {
    public SpeedDecorator(PowerUpLauncher powerUpLauncher) {
        super(powerUpLauncher);
    }

    @Override
    public int applyPowerUp(GameScreenViewModel gameScreenViewModel) {
        gameScreenViewModel.getRoom().slow();
        gameScreenViewModel.getRoom().setPaused(true);
        int powerUpTime = 11;
        return powerUpTime;
    }

    @Override
    public void terminatePowerUp(GameScreenViewModel gameScreenViewModel) {
        gameScreenViewModel.getRoom().quicken();
        gameScreenViewModel.getRoom().setPaused(false);
    }
}
